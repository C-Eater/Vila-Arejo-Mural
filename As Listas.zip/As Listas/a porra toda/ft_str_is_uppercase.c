/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/13 16:03:35 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/14 21:01:14 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

int ft_str_is_uppercase(char *str);

int main()
{
	char str1[4];
	char str2[4] = "asde";
	char str3[4] = "asFe";
	char str4[4] = "A3SE";
	char str5[4] = "ABSE";
	char str6[] = "";
	printf("Teste 1: %d\n",ft_str_is_uppercase(str1));
	printf("Teste 2: %d\n",ft_str_is_uppercase(str2));
	printf("Teste 3: %d\n",ft_str_is_uppercase(str3));
	printf("Teste 4: %d\n",ft_str_is_uppercase(str4));
	printf("Teste 5: %d\n",ft_str_is_uppercase(str5));
	printf("Teste 6: %d\n",ft_str_is_uppercase(str6));
	return (0);
} */

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 65 || str[i] > 90)
			return (0);
		i++;
	}
	return (1);
}
