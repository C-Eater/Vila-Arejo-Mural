/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/10 03:50:05 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/12 05:40:43 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

int	main()
{
	int a;
	int b;
	int div;
	int mod;

	a = 40;
	b = 6;
	
	ft_div_mod(a, b, &div, &mod);
	printf("Div: %d, Mod: %d.\n", div, mod);
	return (0);
} */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
