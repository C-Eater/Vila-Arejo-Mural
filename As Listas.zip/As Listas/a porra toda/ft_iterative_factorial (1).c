/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/16 03:52:24 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 16:48:28 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	factorial;

	if (nb < 0)
		return (0);
	factorial = 1;
	while (nb > 0)
		factorial *= nb--;
	return (factorial);
}

/* #include <stdio.h>

 int main(void)
{
	int	nb;
	
	nb = 3;
	printf("Fatorial = %d\n", ft_iterative_factorial(nb));
} */
