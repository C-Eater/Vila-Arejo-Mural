/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/14 02:46:12 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/16 01:49:10 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find);

int main()
{
	char str[100] = "C é bom, devore!";
	char find[100] = "";

	printf("String Original  : %s\n", str);
	printf("Função Verdadeira: %s\n", strstr(str,find));
	printf("Função Pirata    : %s\n", ft_strstr(str,find));
	return (0);
}*/

char	*ft_strstr(char *str, char *to_find)
{
	char	*i;
	char	*j;

	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{
		i = str;
		j = to_find;
		while (*i == *j && *j != '\0' && *i != '\0')
		{
			++i;
			++j;
		}
		if (*j == '\0')
			return (str);
		++str;
	}
	return (0);
}
