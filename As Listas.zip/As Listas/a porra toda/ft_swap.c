/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/10 03:37:22 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/12 05:35:58 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

void	ft_swap(int *a, int *b);

int	main()
{
	int a;
	int b;

	a = 1;
	b = 2;
	
	ft_swap(&a, &b);
	printf("A: %d, B: %d.\n", a, b);
	return (0);
} */

void	ft_swap(int *a, int *b)
{
	int	t;

	t = *a;
	*a = *b;
	*b = t;
}
