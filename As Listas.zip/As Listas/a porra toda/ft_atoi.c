/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/15 15:58:21 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/16 16:54:50 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

int ft_atoi(char *str);

int main()
{
	printf("%d X\n", ft_atoi("    -342"));
	printf("%d X\n", ft_atoi("   ---+--+1234ab567"));
	return (0);
} */

int	ft_atoi(char *str)
{
	int	sign;
	int	num;

	while ((9 <= *str && *str <= 15) || *str == ' ')
		++str;
	sign = 1;
	while (*str == '+' || *str == '-')
	{
		if (*str == '-')
			sign = -sign;
		++str;
	}
	num = 0;
	while (*str >= '0' && *str <= '9')
	{
		num *= 10;
		num += sign * (*str - '0');
		++str;
	}
	return (num);
}
