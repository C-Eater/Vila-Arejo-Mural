/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/17 17:55:41 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 17:56:38 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	return (ft_recursive_power(nb, power - 1) * nb);
}

/* #include <stdio.h>
int main()
{
	int num = 3;
	int power = 1;

	//printf("%d", ft_iterative_power(num, power));
	printf("%d", ft_recursive_power(num, power));
	return(0);
} */