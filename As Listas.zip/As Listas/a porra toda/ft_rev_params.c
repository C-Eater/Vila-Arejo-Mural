/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/14 01:02:33 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 03:03:08 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	i;
	int	j;

	i = argc - 1;
	j = 0;
	while (i > 0)
	{
		if (argv[i][j] != '\0')
		{
			write(1, &argv[i][j], 1);
			j++;
		}
		else
		{
			write(1, "\n", 1);
			j = 0;
			i--;
		}
	}
	return (0);
}
