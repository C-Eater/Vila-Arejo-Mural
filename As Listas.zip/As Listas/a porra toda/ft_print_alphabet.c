/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/08 03:08:58 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/11 02:02:34 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/* void	ft_print_alphabet(void);

int	main()
{
	ft_print_alphabet();
	return (0);
} */

void	ft_print_alphabet(void)
{
	int		i;
	char	letter;

	i = 0;
	letter = 'a';
	while (i < 26)
	{
		write(1, &letter, 1);
		letter++;
		i++;
	}
}
