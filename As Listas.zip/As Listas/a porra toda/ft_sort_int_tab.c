/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/10 15:35:59 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/13 19:23:36 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void ft_sort_int_tab(int *tab, int size);

int main()
{
	int arr[6] = {2,4,3,1,5,6};
	ft_sort_int_tab(arr, 6);
	return (0);
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	t;

	i = 0;
	while (i < size - 1)
	{
		if (tab[i] > tab[i + 1])
		{
			t = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = t;
			i = 0;
		}
		else
			i++;
	}
	//Cole este trecho antes da ultima chave do código.
	i = 0;
	while (i < size)
	{
		printf("%d", tab[i]);
		i++;
	}
}
