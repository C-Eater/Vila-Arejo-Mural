/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/17 06:05:27 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/18 01:48:47 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int    ft_sqrt(int nb)
{
    unsigned int    i;
    unsigned int    nb1;

    i = 0;
    if (nb < 0)
        nb *= -1;
    nb1 = nb;
    while (i * i < nb1)
        i++;
    if (i * i == nb1)
        return (i);
    return (0);
}

/* #include <stdio.h>
int main()
{
	printf("%d\n", ft_sqrt(-100));
	return (0);
} */