#!/bin/sh
#FT_USER=coder
groups $FT_USER	| tr ' ' ',' | tr -d '\n'