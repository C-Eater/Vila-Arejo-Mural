/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/15 14:42:59 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/16 19:18:24 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/* void ft_putnbr(int nb);

int main()
{
	ft_putnbr(-195);
	return (0);
} */

void	ft_putnbr(int nb)
{
	unsigned int	div;
	unsigned int	num;
	char			c;

	if (nb < 0)
	{
		write(1, "-", 1);
		num = (-1) * nb;
	}
	else
		num = nb;
	div = 1;
	while (nb / 10)
	{
		nb = nb / 10;
		div *= 10;
	}
	while (div)
	{
		c = '0' + num / div;
		write(1, &c, 1);
		num = num % div;
		div = div / 10;
	}
}
