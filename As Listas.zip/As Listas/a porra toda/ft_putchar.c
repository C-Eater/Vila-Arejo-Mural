/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/08 02:59:35 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/11 02:08:46 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/* void	ft_putchar(char c);

int	main(void)
{
	ft_putchar('c');
	return (0);
} */

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
