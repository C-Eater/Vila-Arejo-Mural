/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/10 04:03:31 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/12 05:45:30 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

void 	ft_ultimate_div_mod(int *a, int *b);

int	main()
{
	int a;
	int b;

	a = 40;
	b = 5;
	
	ft_ultimate_div_mod(&a, &b);
	printf("A: %d, B: %d.\n", a, b);
	return (0);
} */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	t1;
	int	t2;

	t1 = *a / *b;
	t2 = *a % *b;
	*a = t1;
	*b = t2;
}
