/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/17 03:29:04 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 17:16:36 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	n;

	if (power < 0)
		return (0);
	n = 1;
	while (power > 0)
	{
		n *= nb;
		--power;
	}
	return (n);
}

/* #include <stdio.h>

int main()
{
	int num = -3;
	int power = 2;

	printf("%d", ft_iterative_power(num, power));
	return(0);
}
 */