/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/14 01:04:06 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 03:08:38 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strcmp(char *s1, char *s2)
{
	while (*s1 != '\0' && *s2 != '\0' && *s1 == *s2)
	{
		s1++;
		s2++;
	}
	return (((int)*s1) - ((int)*s2));
}

void	ft_sort_params(char **arr, int size)
{
	int		max_pos;
	int		i;
	char	*temp;

	max_pos = size;
	while (max_pos > 0)
	{
		i = 0;
		while (++i < max_pos)
		{
			if (ft_strcmp(arr[i - 1], arr[i]) > 0)
			{
				temp = arr[i];
				arr[i] = arr[i - 1];
				arr[i - 1] = temp;
			}
		}
		max_pos--;
	}
}

int	main(int argc, char *argv[])
{
	unsigned int	char_count;
	int				i;
	char			*str;

	i = 0;
	ft_sort_params(argv + 1, argc - 1);
	while (++i < argc)
	{
		char_count = 0;
		str = argv[i];
		while (*str++ != '\0')
		{
			char_count++;
		}
		write(1, argv[i], char_count);
		write(1, "\n", 1);
	}
}
