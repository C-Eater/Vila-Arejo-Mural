/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/13 03:42:23 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/15 00:06:20 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>
#include <ctype.h>

int ft_str_is_alpha(char *str);

int main()
{
	char str[4];
	printf("Teste1: %d\n",ft_str_is_alpha("ab33ef"));
	printf("Teste2: %d\n",ft_str_is_alpha("abeeef"));
	printf("Teste3: %d\n",ft_str_is_alpha("abEEef"));
	printf("Teste4: %d\n",ft_str_is_alpha("ab\n/ef"));
	printf("Teste5: %d\n",ft_str_is_alpha(""));
	printf("Teste6: %d\n",ft_str_is_alpha(str));
		
	return (0);
} */

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[i] < 0)
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if ((str[i] < 65 || str[i] > 90)
			&& (str[i] < 97 || str[i] > 122))
			return (0);
		i++;
	}
	return (1);
}
