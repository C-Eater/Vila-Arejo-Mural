/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/08 14:19:55 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/11 02:22:37 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/* void	ft_print_comb(void);

int	main(void)
{
	ft_print_comb();
	return (0);
} */

void	print_number(char hundreds, char tens, char units)
{
	write(1, &hundreds, 1);
	write(1, &tens, 1);
	write(1, &units, 1);
}

void	list_numbers(char hundreds, char tens, char units)
{
	while (hundreds <= '7')
	{	
		while (tens <= '8')
		{
			if (hundreds < tens)
			{
				while (units <= '9')
				{
					if (tens < units)
					{
						print_number(hundreds, tens, units);
						if (hundreds == '7' && tens == '8' && units == '9')
							write(1, "", 1);
						else
							write(1, ", ", 2);
					}
					units++;
				}
			}
			tens++;
			units = 0;
		}
		hundreds++;
		tens = 0;
	}
}

void	ft_print_comb(void)
{
	char	hundreds;
	char	tens;
	char	units;

	hundreds = '0';
	tens = '0';
	units = '0';
	list_numbers(hundreds, tens, units);
}
