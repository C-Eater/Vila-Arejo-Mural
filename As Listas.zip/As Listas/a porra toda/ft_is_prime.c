/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/17 15:23:14 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/17 22:33:44 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;

	i = 2;
	while (i <= nb / 2) //
	{
		if (nb % i == 0)
			return (0);
		++i;
	}
	return (nb > 1);
}

/* #include <stdio.h>
int main()
{
	printf("%d\n", ft_is_prime(8));
	return (0);
} */
