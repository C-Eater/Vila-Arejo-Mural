/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/13 04:47:24 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/14 20:59:54 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

int ft_str_is_numeric(char *str);

int main()
{
	//char arr[4] = {'0','b','3','5'};
	char arr[4] = "0334";
	//char arr[4];
	printf("%d\n", ft_str_is_numeric(arr));
	return (0);
} */

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	if (str[0] < 0)
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] < '0')
			return (0);
		else if (str[i] > '9')
			return (0);
		i++;
	}
	return (1);
}
