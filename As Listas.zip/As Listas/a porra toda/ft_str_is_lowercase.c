/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/13 15:56:21 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/15 02:23:20 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int ft_str_is_lowercase(char *str);

int main()
{
	char str2[] = "eeee";
	char str3[] = "aste";
	char str4[] = "a3se";
	char str5[] = "abse";
	char str6[] = "";
	//char str1[];
	//printf("Teste 1: %d\n",ft_str_is_lowercase(str1));
	printf("Teste 2: %d\n",ft_str_is_lowercase(str2));
	printf("Teste 3: %d\n",ft_str_is_lowercase(str3));
	printf("Teste 4: %d\n",ft_str_is_lowercase(str4));
	printf("Teste 5: %d\n",ft_str_is_lowercase(str5));
	printf("Teste 6: %d\n",ft_str_is_lowercase(str6));
	return (0);
}

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 97 || str[i] > 122)
			return (0);
		i++;
	}
	return (1);
}
