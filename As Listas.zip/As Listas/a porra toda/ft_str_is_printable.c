/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/13 16:07:57 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/14 21:20:37 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

int ft_str_is_printable(char *str);

int main()
{
	char str1[4];
	char str2[4] = "asé";
	char str3[4] = "as\ne";
	char str4[4] = "A3SE";
	char str5[4] = "AB/E";
	char str6[] = "";
	printf("Teste 1: %d\n",ft_str_is_printable(str1));
	printf("Teste 2: %d\n",ft_str_is_printable(str2));
	printf("Teste 3: %d\n",ft_str_is_printable(str3));
	printf("Teste 4: %d\n",ft_str_is_printable(str4));
	printf("Teste 5: %d\n",ft_str_is_printable(str5));
	printf("Teste 6: %d\n",ft_str_is_printable(str6));
	return (0);
} */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < 32 || str[i] > 126)
			return (0);
		i++;
	}
	return (1);
}
