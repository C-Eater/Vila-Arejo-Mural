/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tde-souz <thawancamara@gmail.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/10 04:35:45 by tde-souz          #+#    #+#             */
/*   Updated: 2021/12/12 14:54:45 by tde-souz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>

void ft_rev_int_tab(int *tab, int size);

int	main()
{
	int arr[9] = {1,2,3,4,5,6,0,8,9};
	
	ft_rev_int_tab(arr, 9);
	return (0);
}
	//Teste da função
	i = 0;
	while (i < size)
	{
		printf("%d", tab[i]);
		i++;
	} */

void	ft_rev_int_tab(int *tab, int size)
{
	int	t;
	int	i;
	int	ri;

	i = 0;
	ri = size - 1;
	while (i < (size / 2))
	{
		t = tab[ri];
		tab[ri] = tab[i];
		tab[i] = t;
		i++;
		ri--;
	}
}
